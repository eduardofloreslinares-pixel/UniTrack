# UniTrack para iOS

App nativa en SwiftUI para iOS 26 o posterior. Usa Liquid Glass de Apple, pestañas nativas y la apariencia clara u oscura del sistema. El registro de cursos se guarda localmente.

## Compilar desde GitHub con el ZIP

1. Sube `UniTrack-iOS.zip` a la raíz de tu repositorio.
2. Crea `.github/workflows/build-ipa.yml` en el repositorio y pega el contenido de `workflow-para-github.txt` incluido en el ZIP. GitHub detecta el workflow desde esa ruta.
3. En **Actions → Compilar IPA de UniTrack**, pulsa **Run workflow**. También se ejecuta con cambios relevantes en `main` o `master`.
4. En el run terminado, descarga el artefacto **UniTrack-iOS** y extrae **UniTrack.ipa**. La IPA se genera sin firmar para que puedas usar tu flujo de firma e instalación en iPhone.

Si prefieres subir el proyecto descomprimido, coloca las carpetas `UniTrack`, `UniTrack.xcodeproj` y `.github` en la raíz. El mismo workflow admite ambas formas.

## Traer tus datos de Android

Exporta el respaldo JSON desde UniTrack en Android. Guárdalo en Archivos en el iPhone y elígelo en **Ajustes → Importar JSON** dentro de UniTrack. La app confirma antes de reemplazar sus datos locales. El proyecto abre vacío y el ZIP se puede compartir sin incluir tus datos académicos.

## Abrir en Xcode

Abre `UniTrack.xcodeproj` con Xcode 26 o posterior. Para instalar desde Xcode, selecciona tu equipo en **Signing & Capabilities**. El identificador inicial es `com.eduardoflores.unitrack`.
