import SwiftUI

@main
struct UniTrackApp: App {
    @StateObject private var school = School()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            TabView {
                NavigationStack { Dashboard() }
                    .tabItem { Label("Cursos", systemImage: "graduationcap") }
                NavigationStack { Agenda() }
                    .tabItem { Label("Calendario", systemImage: "calendar") }
                NavigationStack { Simulator() }
                    .tabItem { Label("Simular", systemImage: "slider.horizontal.3") }
                NavigationStack { ArchiveView() }
                    .tabItem { Label("Histórico", systemImage: "archivebox") }
                NavigationStack { Preferences() }
                    .tabItem { Label("Ajustes", systemImage: "gearshape") }
            }
            .environmentObject(school)
            .tint(.indigo)
            .onChange(of: scenePhase, initial: true) { _, phase in
                if phase == .active { school.closeIfDue() }
            }
            .alert("Datos locales", isPresented: Binding(
                get: { school.storageError != nil },
                set: { if !$0 { school.storageError = nil } }
            )) {
                Button("Aceptar") { school.storageError = nil }
            } message: { Text(school.storageError ?? "") }
        }
    }
}

struct GlassCard<Content: View>: View {
    var tint: Color = .indigo
    var fillsHeight = false
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            content
        }
            .frame(maxWidth: .infinity, maxHeight: fillsHeight ? .infinity : nil, alignment: .topLeading)
            .padding(16)
            .glassEffect(.regular.tint(tint.opacity(0.12)), in: RoundedRectangle(cornerRadius: 24))
    }
}

extension View {
    func trackBackground() -> some View {
        background {
            LinearGradient(colors: [.indigo.opacity(0.15), Color(uiColor: .systemGroupedBackground), .teal.opacity(0.09)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
        }
    }
}

struct Dashboard: View {
    @EnvironmentObject private var school: School
    @State private var addCourse = false
    @State private var addCycle = false

    private var ordered: [Course] {
        school.active.sorted { (Grades.average($0) ?? 21, $0.name) < (Grades.average($1) ?? 21, $1.name) }
    }

    var body: some View {
        ScrollView {
            if let cycle = school.data.currentCycle {
                VStack(spacing: 16) {
                    NavigationLink {
                        CycleOverview()
                    } label: {
                        GlassCard {
                            let progress = CycleProgress(cycle)
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(cycle.name).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                                    Text("Semana \(progress.week) de \(progress.weeks)")
                                        .font(.title2.bold())
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(.secondary)
                            }
                            GeometryReader { proxy in
                                Capsule().fill(.secondary.opacity(0.14))
                                    .overlay(alignment: .leading) {
                                        LinearGradient(stops: [
                                            .init(color: .green, location: 0),
                                            .init(color: .yellow, location: 0.45),
                                            .init(color: .orange, location: 0.7),
                                            .init(color: .red, location: 1)
                                        ], startPoint: .leading, endPoint: .trailing)
                                        .frame(width: proxy.size.width)
                                        .frame(width: proxy.size.width * progress.fraction, alignment: .leading)
                                        .clipShape(Capsule())
                                    }
                            }.frame(height: 8)
                            HStack {
                                Text("\(progress.remaining) días restantes")
                                Spacer()
                                Text("\(Int(progress.fraction * 100))% transcurrido")
                                    .monospacedDigit()
                            }
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                        }
                    }.buttonStyle(.plain)

                    let averages = ordered.compactMap { Grades.average($0) }
                    if !averages.isEmpty {
                        let general = Grades.truncate(averages.reduce(0, +) / Decimal(averages.count))
                        GlassCard {
                            HStack {
                                Label("Promedio general", systemImage: "chart.bar").font(.subheadline.weight(.semibold))
                                Spacer()
                                Text(Grades.label(general)).font(.title2.monospacedDigit().bold())
                            }
                        }
                    }

                    let passing = ordered.filter { (Grades.average($0) ?? -1) >= school.data.settings.minPassingGrade }
                    let failing = ordered.filter { course in
                        Grades.average(course).map { $0 < school.data.settings.minPassingGrade } ?? false
                    }
                    HStack(alignment: .top, spacing: 12) {
                        statusCard("Aprobando", passing, .green, "checkmark.circle")
                        statusCard("Desaprobando", failing, .red, "exclamationmark.circle")
                    }
                    .fixedSize(horizontal: false, vertical: true)
                    let upcoming = ordered.flatMap(\.appointments)
                        .filter { $0.part.obtainedGrade == nil && ($0.part.date ?? "") >= Dates.today }
                        .sorted { ($0.part.date ?? "") < ($1.part.date ?? "") }.prefix(3)
                    if !upcoming.isEmpty {
                        NavigationLink { Agenda() } label: {
                            GlassCard(tint: .blue) {
                                VStack(alignment: .leading, spacing: 7) {
                                    Label("Próximas evaluaciones", systemImage: "calendar").font(.subheadline.bold())
                                    ForEach(upcoming) { item in
                                        Text(item.part.name + " · " + item.course.name).font(.footnote)
                                        Text(Dates.label(item.part.date)).font(.caption2).foregroundStyle(.secondary)
                                    }
                                }
                            }
                        }.buttonStyle(.plain)
                    }
                    Text("Cursos del periodo").font(.title3.bold()).frame(maxWidth: .infinity, alignment: .leading)
                    if ordered.isEmpty {
                        ContentUnavailableView("Sin cursos", systemImage: "books.vertical",
                                               description: Text("Toca + para registrar tu primer curso."))
                    }
                    ForEach(ordered) { course in
                        NavigationLink {
                            CourseView(courseID: course.id)
                        } label: {
                            CourseCard(course: course)
                                .contentShape(RoundedRectangle(cornerRadius: 24))
                        }
                        .buttonStyle(.plain)
                    }
                }.padding()
            } else {
                ContentUnavailableView {
                    Label("Abre tu ciclo", systemImage: "graduationcap")
                } description: {
                    Text("Organiza tus notas, evaluaciones y próximos exámenes.")
                } actions: {
                    Button("Nuevo ciclo") { addCycle = true }.buttonStyle(.glassProminent)
                }
            }
        }
        .trackBackground()
        .navigationTitle("UniTrack")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button(school.data.currentCycle == nil ? "Nuevo ciclo" : "Agregar curso", systemImage: "plus") {
                    if school.data.currentCycle == nil { addCycle = true } else { addCourse = true }
                }
            }
        }
        .sheet(isPresented: $addCycle) { CycleEditor() }
        .sheet(isPresented: $addCourse) {
            if let cycle = school.data.currentCycle { CourseEditor(course: Course(cycleId: cycle.id)) }
        }
    }

    private func statusCard(_ title: String, _ courses: [Course], _ color: Color, _ icon: String) -> some View {
        GlassCard(tint: color, fillsHeight: true) {
            VStack(alignment: .leading, spacing: 5) {
                Label(title, systemImage: icon).font(.caption.weight(.semibold)).foregroundStyle(color)
                Text(courses.count.formatted()).font(.title.bold())
                if !courses.isEmpty {
                    Text(courses.map { $0.name.split(whereSeparator: { $0.isWhitespace }).first.map(String.init) ?? $0.name }
                        .joined(separator: " · "))
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
        }
    }
}

struct CourseCard: View {
    @EnvironmentObject private var school: School
    let course: Course

    var body: some View {
        let average = Grades.average(course)
        let passing = (average ?? -1) >= school.data.settings.minPassingGrade
        let final = course.evaluations.flatMap(\.entries).allSatisfy { $0.obtainedGrade != nil }
        let color: Color = average == nil ? .indigo : (passing ? .green : .red)
        let next = course.appointments.filter { $0.part.obtainedGrade == nil && ($0.part.date ?? "") >= Dates.today }
            .min { ($0.part.date ?? "") < ($1.part.date ?? "") }
        GlassCard(tint: color) {
            VStack(alignment: .leading, spacing: 9) {
                HStack {
                    Text(course.code).font(.caption.monospaced().weight(.semibold))
                    Spacer()
                    Text(average == nil ? "Sin promedio" : (passing ? (final ? "Aprobado" : "Aprobando") : (final ? "Desaprobado" : "Desaprobando")))
                        .font(.caption.weight(.semibold)).foregroundStyle(color)
                }
                Text(course.name).font(.headline)
                if !course.teacherName.isEmpty {
                    Label(course.teacherName, systemImage: "person").font(.footnote).foregroundStyle(.secondary)
                }
                if !course.whatIsNeededToPass.isEmpty {
                    Text(course.whatIsNeededToPass).font(.footnote)
                }
                Divider()
                HStack(spacing: 8) {
                    VStack(spacing: 4) {
                        Text("Promedio calculado").font(.caption2).foregroundStyle(.secondary)
                        Text(Grades.label(average)).font(.title2.monospacedDigit().bold()).foregroundStyle(color)
                        Text("Asegurado: " + Grades.label(Grades.average(course, secured: true)))
                            .font(.caption2).foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity)
                    VStack(spacing: 4) {
                        Text("Siguiente evaluación").font(.caption2).foregroundStyle(.secondary)
                        Text(next?.part.name ?? "Sin pendientes con fecha").font(.subheadline.weight(.medium))
                        if let next { Text(Dates.label(next.part.date)).font(.caption2).foregroundStyle(.secondary) }
                    }.frame(maxWidth: .infinity)
                }.multilineTextAlignment(.center)
            }
        }
    }
}

