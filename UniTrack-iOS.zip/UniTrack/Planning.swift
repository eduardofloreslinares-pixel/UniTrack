import SwiftUI

struct Agenda: View {
    @EnvironmentObject private var school: School

    @State private var includePast = false

    var body: some View {
        let courses = school.active
        let byDate = Dictionary(grouping: courses.flatMap(\.appointments).filter { includePast || ($0.part.date ?? "") >= Dates.today }) {
            $0.part.date ?? ""
        }
        let continuous = courses.flatMap { course in
            course.evaluations.flatMap(\.entries).filter { ($0.date ?? "").isEmpty && $0.obtainedGrade == nil }.map {
                Appointment(course: course, part: $0)
            }
        }
        List {
            ForEach(byDate.keys.sorted(), id: \.self) { date in
                Section(Dates.label(date)) {
                    ForEach(byDate[date] ?? []) { item in appointment(item) }
                }
            }
            if !continuous.isEmpty {
                Section("Evaluaciones continuas") { ForEach(continuous) { appointment($0) } }
            }
            if byDate.isEmpty && continuous.isEmpty {
                ContentUnavailableView("Sin evaluaciones próximas", systemImage: "calendar")
            }
        }
        .navigationTitle("Calendario")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu("Mostrar", systemImage: "line.3.horizontal.decrease") {
                    Toggle("Incluir fechas pasadas", isOn: $includePast)
                }
            }
        }
    }

    private func appointment(_ item: Appointment) -> some View {
        NavigationLink { CourseView(courseID: item.course.id) } label: {
            VStack(alignment: .leading, spacing: 4) {
                Text(item.part.name).font(.headline)
                Text(item.course.name).font(.caption).foregroundStyle(.secondary)
                if item.part.obtainedGrade != nil {
                    Text("Calificada").font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
    }
}

struct Simulator: View {
    @EnvironmentObject private var school: School
    @State private var overrides: [String: [String: Decimal]] = [:]
    @State private var selected = ""
    @State private var showCycle = false

    private var course: Course? { school.active.first { $0.id == selected } ?? school.active.first }

    var body: some View {
        Group {
            if let course {
                List {
                    Section {
                        Picker("Curso", selection: Binding(get: { course.id }, set: { selected = $0 })) {
                            ForEach(school.active) { Text($0.name).tag($0.id) }
                        }
                    }
                    Section {
                        ForEach(course.evaluations) { evaluation in
                            DisclosureGroup {
                                ForEach(evaluation.entries) { part in
                                    GradeField(part.name, value: Binding(
                                        get: { overrides[course.id]?[part.id] },
                                        set: { value in overrides[course.id, default: [:]][part.id] = value }
                                    ))
                                    .id(course.id + ":" + part.id)
                                    Text("Obtenida \(Grades.label(part.obtainedGrade)) · Esperada \(Grades.label(part.expectedGrade))")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            } label: {
                                let values = Grades.scores(evaluation, overrides: overrides[course.id] ?? [:])
                                let mean = values.map { Grades.truncate($0.reduce(0, +) / Decimal($0.count)) }
                                LabeledContent(evaluation.name, value: Grades.label(mean))
                            }
                        }
                    }
                }
                .safeAreaInset(edge: .top, spacing: 0) {
                    GlassCard {
                        HStack {
                            VStack(alignment: .leading) {
                                Text("Original").font(.caption).foregroundStyle(.secondary)
                                Text(Grades.label(Grades.average(course))).font(.title2.bold()).monospacedDigit()
                            }
                            Spacer()
                            VStack(alignment: .trailing) {
                                let average = Grades.average(course, overrides: overrides[course.id] ?? [:])
                                Text("Simulado").font(.caption).foregroundStyle(.secondary)
                                Text(Grades.label(average)).font(.title2.bold()).monospacedDigit()
                                    .foregroundStyle(average.map { $0 >= school.data.settings.minPassingGrade ? Color.green : Color.red } ?? .secondary)
                            }
                        }
                    }.padding(.horizontal)
                }
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Simulación del ciclo", systemImage: "list.number") { showCycle = true }
                    }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Restablecer curso", systemImage: "arrow.counterclockwise") { overrides[course.id] = nil }
                    }
                }
            } else {
                ContentUnavailableView("Sin cursos para simular", systemImage: "slider.horizontal.3")
            }
        }
        .navigationTitle("Simular")
        .sheet(isPresented: $showCycle) {
            NavigationStack {
                List {
                    let averages = school.active.map { Grades.average($0, overrides: overrides[$0.id] ?? [:]) }
                    let available = averages.compactMap { $0 }
                    let mean = !available.isEmpty && available.count == averages.count
                        ? Grades.truncate(available.reduce(0, +) / Decimal(available.count)) : nil
                    Section { LabeledContent("Promedio del ciclo", value: Grades.label(mean)) }
                    ForEach(school.active) { course in
                        LabeledContent(course.name, value: Grades.label(Grades.average(course, overrides: overrides[course.id] ?? [:])))
                    }
                }
                .navigationTitle("Simulación del ciclo")
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) { Button("Listo") { showCycle = false } }
                }
            }
        }
    }
}

struct ArchiveView: View {
    @EnvironmentObject private var school: School

    var body: some View {
        List {
            let retired = school.data.courses.filter(\.isRetired)
            if !retired.isEmpty {
                Section("Cursos retirados") { ForEach(retired) { courseLink($0) } }
            }
            ForEach(school.data.historicCycles) { cycle in
                Section(cycle.name) {
                    Text(Dates.label(cycle.startDate) + " – " + Dates.label(cycle.endDate))
                        .font(.caption).foregroundStyle(.secondary)
                    ForEach(school.data.courses.filter { $0.cycleId == cycle.id && !$0.isRetired }) { courseLink($0) }
                }
            }
            if retired.isEmpty && school.data.historicCycles.isEmpty {
                ContentUnavailableView("Histórico vacío", systemImage: "archivebox")
            }
        }.navigationTitle("Histórico")
    }

    private func courseLink(_ course: Course) -> some View {
        NavigationLink { CourseView(courseID: course.id, readOnly: true) } label: {
            LabeledContent(course.name, value: Grades.label(Grades.average(course)))
        }
    }
}
