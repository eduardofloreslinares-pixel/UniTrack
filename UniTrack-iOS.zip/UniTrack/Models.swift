import Foundation
import SwiftUI

struct Part: Codable, Identifiable {
    var id = UUID().uuidString
    var name = ""
    var date: String?
    var obtainedGrade: Decimal?
    var expectedGrade: Decimal?
}

struct Evaluation: Codable, Identifiable {
    var id = UUID().uuidString
    var name = ""
    var weight: Decimal = 0
    var isGroup = false
    var dropLowestCount = 0
    var parts: [Part] = []
    var date: String?
    var obtainedGrade: Decimal?
    var expectedGrade: Decimal?

    var entries: [Part] {
        isGroup ? parts : [Part(id: id, name: name, date: date, obtainedGrade: obtainedGrade, expectedGrade: expectedGrade)]
    }
}

struct Course: Codable, Identifiable {
    var id = UUID().uuidString
    var cycleId: String
    var name = ""
    var code = ""
    var teacherName = ""
    var whatIsNeededToPass = ""
    var evaluations: [Evaluation] = []
    var isRetired = false
    var notes: String?
}

struct Cycle: Codable, Identifiable {
    var id = UUID().uuidString
    var name: String
    var startDate: String
    var endDate: String
    var isClosed = false
}

struct Settings: Codable {
    var minPassingGrade: Decimal = 11
}

struct SchoolData: Codable {
    var currentCycle: Cycle?
    var historicCycles: [Cycle] = []
    var courses: [Course] = []
    var settings = Settings()
}

@MainActor
final class School: ObservableObject {
    @Published var data: SchoolData { didSet { persist() } }
    @Published var storageError: String?
    private let url: URL

    init() {
        url = URL.applicationSupportDirectory.appending(path: "UniTrack.json")
        if FileManager.default.fileExists(atPath: url.path) {
            do { data = try JSONDecoder().decode(SchoolData.self, from: Data(contentsOf: url)) }
            catch {
                data = SchoolData()
                storageError = "No se pudo abrir el registro local."
            }
        } else { data = SchoolData() }
    }

    private func persist() {
        do {
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try JSONEncoder().encode(data).write(to: url, options: .atomic)
        } catch { storageError = "No se pudo guardar el registro local." }
    }

    var active: [Course] {
        data.courses.filter { $0.cycleId == data.currentCycle?.id && !$0.isRetired }
    }

    func put(_ course: Course) {
        if let index = data.courses.firstIndex(where: { $0.id == course.id }) { data.courses[index] = course }
        else { data.courses.append(course) }
    }

    func closeIfDue() {
        if let cycle = data.currentCycle, !cycle.isClosed, cycle.endDate < Dates.today { closeCycle() }
    }

    func closeCycle() {
        guard var cycle = data.currentCycle else { return }
        cycle.isClosed = true
        var updated = data
        updated.historicCycles.removeAll { $0.id == cycle.id }
        updated.historicCycles.insert(cycle, at: 0)
        updated.currentCycle = nil
        data = updated
    }
}

enum Dates {
    static func formatter(_ format: String) -> DateFormatter {
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_PE")
        f.calendar = Calendar(identifier: .gregorian)
        f.dateFormat = format
        return f
    }

    static var today: String { iso(Date()) }
    static func iso(_ date: Date) -> String { formatter("yyyy-MM-dd").string(from: date) }
    static func parse(_ raw: String) -> Date? { formatter("yyyy-MM-dd").date(from: raw) }
    static func label(_ raw: String?) -> String {
        guard let raw, !raw.isEmpty else { return "Continua" }
        guard let date = parse(raw) else { return raw }
        return formatter("EEEE dd/MM/yy").string(from: date).capitalized
    }
}

struct Appointment: Identifiable {
    var course: Course
    var part: Part
    var id: String { course.id + ":" + part.id }
}

extension Course {
    var appointments: [Appointment] {
        evaluations.flatMap { evaluation in
            evaluation.entries.compactMap { part in
                guard let date = part.date, !date.isEmpty else { return nil }
                return Appointment(course: self, part: part)
            }
        }
    }
}

enum Grades {
    // Apply the same drop rule to recorded, expected, and simulated values.
    static func scores(_ evaluation: Evaluation, secured: Bool = false, overrides: [String: Decimal] = [:]) -> [Decimal]? {
        let entries = evaluation.entries
        guard !entries.isEmpty else { return nil }
        let scores: [Decimal?] = entries.map { entry in
            if secured { return entry.obtainedGrade ?? 0 }
            return overrides[entry.id] ?? entry.obtainedGrade ?? entry.expectedGrade
        }
        guard scores.allSatisfy({ $0 != nil }) else { return nil }
        let drops = evaluation.isGroup ? min(max(evaluation.dropLowestCount, 0), entries.count - 1) : 0
        return Array(scores.compactMap { $0 }.sorted().dropFirst(drops))
    }

    static func truncate(_ value: Decimal) -> Decimal {
        var value = value
        var result = Decimal()
        NSDecimalRound(&result, &value, 2, .down)
        return result
    }

    static func average(_ course: Course, secured: Bool = false, overrides: [String: Decimal] = [:]) -> Decimal? {
        let weight = course.evaluations.reduce(Decimal.zero) { $0 + $1.weight }
        guard weight == 100 else { return nil }
        var numerator: Decimal = 0
        var denominator: Decimal = 1
        for evaluation in course.evaluations where evaluation.weight > 0 {
            guard let values = scores(evaluation, secured: secured, overrides: overrides) else { return nil }
            let count = Decimal(values.count)
            numerator = numerator * count + values.reduce(0, +) * evaluation.weight * denominator
            denominator *= count
        }
        return truncate(numerator / (denominator * weight))
    }

    static func label(_ value: Decimal?) -> String {
        guard let value else { return "—" }
        return value.formatted(.number.precision(.fractionLength(2)).locale(Locale(identifier: "en_US_POSIX")))
    }

    static func parse(_ text: String) -> Decimal? {
        let normalized = text.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: ",", with: ".")
        guard normalized.range(of: #"^\d+(\.\d*)?$"#, options: .regularExpression) != nil,
              let value = Decimal(string: normalized, locale: Locale(identifier: "en_US_POSIX")), value >= 0, value <= 20 else { return nil }
        return value
    }
}
