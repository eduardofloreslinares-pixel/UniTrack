import SwiftUI

struct CycleProgress {
    let week: Int
    let weeks: Int
    let fraction: CGFloat
    let remaining: Int
    init(_ cycle: Cycle) {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let start = Dates.parse(cycle.startDate) ?? today
        let end = Dates.parse(cycle.endDate) ?? today
        let total = max(1, calendar.dateComponents([.day], from: start, to: end).day ?? 1)
        let elapsed = max(0, calendar.dateComponents([.day], from: start, to: today).day ?? 0)
        weeks = (total + 7) / 7
        week = min(weeks, elapsed / 7 + 1)
        fraction = min(1, CGFloat(elapsed) / CGFloat(total))
        remaining = max(0, calendar.dateComponents([.day], from: today, to: end).day ?? 0)
    }
}

struct CycleOverview: View {
    @EnvironmentObject private var school: School
    var body: some View {
        List {
            ForEach(school.active.sorted { (Grades.average($0) ?? 21) < (Grades.average($1) ?? 21) }) { course in
                NavigationLink { CourseView(courseID: course.id) } label: {
                    let average = Grades.average(course)
                    HStack {
                        Text(course.name)
                        Spacer()
                        Text(Grades.label(average)).monospacedDigit()
                            .foregroundStyle(average.map { $0 >= school.data.settings.minPassingGrade ? Color.green : Color.red } ?? .secondary)
                    }
                }
            }
        }.navigationTitle("Estado del ciclo")
    }
}
