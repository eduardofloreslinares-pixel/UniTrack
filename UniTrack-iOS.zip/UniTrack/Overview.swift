import SwiftUI

struct CycleProgress {
    let week: Int
    let weeks: Int
    let fraction: CGFloat
    let remaining: Int
    init(_ cycle: Cycle) {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let start = Dates.parse(cycle.startDate) ?? today
        let end = Dates.parse(cycle.endDate) ?? today
        let total = max(1, calendar.dateComponents([.day], from: start, to: end).day ?? 1)
        let elapsed = max(0, calendar.dateComponents([.day], from: start, to: today).day ?? 0)
        weeks = (total + 7) / 7
        week = min(weeks, elapsed / 7 + 1)
        fraction = min(1, CGFloat(elapsed) / CGFloat(total))
        remaining = max(0, calendar.dateComponents([.day], from: today, to: end).day ?? 0)
    }
}

struct CycleOverview: View {
    @EnvironmentObject private var school: School
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var revealed = false

    private struct CourseStanding: Identifiable {
        let course: Course
        let average: Decimal?
        var id: String { course.id }
    }

    var body: some View {
        let minimum = school.data.settings.minPassingGrade
        let ranked = school.active.map { CourseStanding(course: $0, average: Grades.average($0)) }
            .sorted { ($0.average ?? 21, $0.course.name) < ($1.average ?? 21, $1.course.name) }
        let failing = ranked.filter { $0.average.map { $0 < minimum } ?? false }
        let passing = ranked.filter { $0.average.map { $0 >= minimum } ?? false }
        let pending = ranked.filter { $0.average == nil }

        ScrollView {
            if let cycle = school.data.currentCycle {
                VStack(alignment: .leading, spacing: 18) {
                    cycleSummary(cycle, active: ranked.count, failing: failing.count,
                                 passing: passing.count, pending: pending.count, minimum: minimum)

                    if let priority = failing.first, let average = priority.average {
                        GlassCard(tint: .red) {
                            Label("Prioridad de estudio", systemImage: "exclamationmark.circle")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.red)
                            let name = Text(priority.course.name).font(.title3.bold()).foregroundColor(.red)
                            let score = Text(Grades.label(average)).font(.title2.bold().monospacedDigit()).foregroundColor(.red)
                            Text("\(name) tiene el promedio más bajo del ciclo: \(score).")
                                .font(.body)
                                .lineSpacing(4)
                            if !priority.course.whatIsNeededToPass.isEmpty {
                                Text(priority.course.whatIsNeededToPass)
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                            }
                            if let next = priority.course.appointments
                                .filter({ $0.part.obtainedGrade == nil && ($0.part.date ?? "") >= Dates.today })
                                .min(by: { ($0.part.date ?? "") < ($1.part.date ?? "") }) {
                                Label(next.part.name + " · " + Dates.label(next.part.date), systemImage: "calendar")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }

                    if !ranked.isEmpty {
                        Text("Cursos del ciclo")
                            .font(.title3.bold())
                            .accessibilityAddTraits(.isHeader)
                        ForEach(ranked) { item in
                            courseRow(item.course, average: item.average, minimum: minimum)
                        }
                    }
                }
                .padding()
                .offset(y: revealed || reduceMotion ? 0 : 10)
                .opacity(revealed || reduceMotion ? 1 : 0.85)
            } else {
                ContentUnavailableView("Sin ciclo activo", systemImage: "calendar")
            }
        }
        .trackBackground()
        .navigationTitle("Estado del ciclo")
        .onAppear {
            withAnimation(reduceMotion ? nil : .smooth(duration: 0.38)) {
                revealed = true
            }
        }
    }

    private func cycleSummary(_ cycle: Cycle, active: Int, failing: Int, passing: Int,
                              pending: Int, minimum: Decimal) -> some View {
        let progress = CycleProgress(cycle)
        return GlassCard {
            Label(cycle.name, systemImage: "calendar")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.indigo)
            Text("Semana \(progress.week) de \(progress.weeks)")
                .font(.largeTitle.bold())
                .accessibilityAddTraits(.isHeader)
            Text("Quedan \(progress.remaining) días para que termine el ciclo.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            if active == 0 {
                Text("Aún no has registrado cursos en este ciclo.").font(.body)
            } else {
                let approved = Text("\(passing) aprobando")
                    .font(.title3.bold()).foregroundColor(.green)
                let atRisk = Text("\(failing) desaprobando")
                    .font(.title3.bold()).foregroundColor(.red)
                Text("De tus \(active) cursos activos, tienes \(approved) y \(atRisk).")
                    .font(.body)
                    .lineSpacing(5)
                if pending > 0 {
                    Text(pending == 1 ? "1 curso aún no tiene promedio." : "\(pending) cursos aún no tienen promedio.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            Text("Mínima aprobatoria · \(Grades.label(minimum))")
                .font(.footnote.monospacedDigit())
                .foregroundStyle(.secondary)
        }
    }

    private func courseRow(_ course: Course, average: Decimal?, minimum: Decimal) -> some View {
        let color = average.map { $0 >= minimum ? Color.green : Color.red } ?? Color.indigo
        return NavigationLink {
            CourseView(courseID: course.id)
        } label: {
            GlassCard(tint: color) {
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(course.name).font(.subheadline.weight(.semibold))
                        if !course.teacherName.isEmpty {
                            Text(course.teacherName).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    Spacer(minLength: 0)
                    Text(Grades.label(average))
                        .font(.title3.weight(.semibold).monospacedDigit())
                        .foregroundStyle(color)
                        .fixedSize()
                        .accessibilityLabel(average == nil ? "Sin promedio" : "Promedio \(Grades.label(average))")
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .accessibilityHidden(true)
                }
            }
            .contentShape(RoundedRectangle(cornerRadius: 24))
        }
        .buttonStyle(.plain)
    }
}
