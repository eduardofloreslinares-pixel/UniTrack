import SwiftUI
import UniformTypeIdentifiers

struct CycleEditor: View {
    @EnvironmentObject private var school: School
    @Environment(\.dismiss) private var dismiss
    var cycle: Cycle?

    init(cycle: Cycle? = nil) { self.cycle = cycle }
    @State private var name = ""
    @State private var start = Date()
    @State private var end = Calendar.current.date(byAdding: .weekOfYear, value: 16, to: Date()) ?? Date()

    var body: some View {
        NavigationStack {
            Form {
                TextField("Nombre del ciclo", text: $name)
                DatePicker("Inicio", selection: $start, displayedComponents: .date)
                DatePicker("Fin", selection: $end, displayedComponents: .date)
            }
            .navigationTitle(cycle == nil ? "Nuevo ciclo" : "Editar ciclo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") {
                        var edited = cycle ?? Cycle(name: name, startDate: "", endDate: "")
                        edited.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
                        edited.startDate = Dates.iso(start)
                        edited.endDate = Dates.iso(end)
                        school.data.currentCycle = edited
                        school.closeIfDue()
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || Dates.iso(end) < Dates.iso(start))
                }
            }
            .onAppear {
                if let cycle {
                    name = cycle.name
                    start = Dates.parse(cycle.startDate) ?? start
                    end = Dates.parse(cycle.endDate) ?? end
                }
            }
        }
    }
}

struct Backup: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var contents: Data
    init(contents: Data) { self.contents = contents }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        contents = data
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: contents)
    }
}

struct Preferences: View {
    @EnvironmentObject private var school: School
    @State private var editing = false
    @State private var closing = false
    @State private var importing = false
    @State private var exporting = false
    @State private var document: Backup?
    @State private var imported: SchoolData?
    @State private var confirmImport = false

    var body: some View {
        Form {
            Section("Ciclo académico") {
                if let cycle = school.data.currentCycle {
                    LabeledContent("Ciclo actual", value: cycle.name)
                    Button("Editar fechas y nombre", systemImage: "calendar") { editing = true }
                    Button("Cerrar ciclo", systemImage: "archivebox", role: .destructive) { closing = true }
                } else {
                    Button("Nuevo ciclo", systemImage: "plus") { editing = true }
                }
            }
            Section("Notas") {
                GradeField("Mínima aprobatoria", value: Binding(
                    get: { school.data.settings.minPassingGrade },
                    set: { if let value = $0 { school.data.settings.minPassingGrade = value } }
                ))
            }
            Section("Respaldo") {
                Button("Importar JSON", systemImage: "square.and.arrow.down") { importing = true }
                Button("Exportar JSON", systemImage: "square.and.arrow.up") {
                    do {
                        let encoder = JSONEncoder()
                        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
                        document = Backup(contents: try encoder.encode(school.data))
                        exporting = true
                    } catch { school.storageError = error.localizedDescription }
                }
            }
        }
        .navigationTitle("Ajustes")
        .sheet(isPresented: $editing) { CycleEditor(cycle: school.data.currentCycle) }
        .confirmationDialog("El ciclo pasará al histórico.", isPresented: $closing, titleVisibility: .visible) {
            Button("Cerrar ciclo", role: .destructive) { school.closeCycle() }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
            do {
                let url = try result.get()
                let accessed = url.startAccessingSecurityScopedResource()
                defer { if accessed { url.stopAccessingSecurityScopedResource() } }
                let data = try Data(contentsOf: url)
                var backup = try JSONDecoder().decode(SchoolData.self, from: data)
                if backup.currentCycle?.id == "unconfigured" { backup.currentCycle = nil }
                imported = backup
                confirmImport = true
            } catch { school.storageError = "No se pudo leer el respaldo de UniTrack." }
        }
        .fileExporter(isPresented: $exporting, document: document, contentType: .json, defaultFilename: "UniTrack-backup") { result in
            if case let .failure(error) = result { school.storageError = error.localizedDescription }
        }
        .alert("¿Importar el respaldo?", isPresented: $confirmImport) {
            Button("Cancelar", role: .cancel) { imported = nil }
            Button("Reemplazar datos", role: .destructive) {
                if let imported { school.data = imported; school.closeIfDue() }
                imported = nil
            }
        } message: {
            Text("Los cursos, ciclos y ajustes de este iPhone se reemplazarán por los del archivo.")
        }
    }
}
