import SwiftUI

struct CourseView: View {
    @EnvironmentObject private var school: School
    let courseID: String
    var readOnly = false
    @State private var editing = false

    var body: some View {
        Group {
            if let course = school.data.courses.first(where: { $0.id == courseID }) {
                let locked = readOnly || course.isRetired || course.cycleId != school.data.currentCycle?.id
                List {
                    Section {
                        CourseCard(course: course).listRowInsets(EdgeInsets()).listRowBackground(Color.clear)
                        if let notes = course.notes, !notes.isEmpty { Text(notes) }
                    }
                    ForEach(course.evaluations) { evaluation in
                        Section {
                            ForEach(evaluation.entries) { part in
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack {
                                        Text(part.name)
                                        Spacer()
                                        Text(Dates.label(part.date)).font(.caption).foregroundStyle(.secondary)
                                    }
                                    HStack {
                                        GradeField("Obtenida", value: grade(evaluation, part, false), locked: locked)
                                        GradeField("Esperada", value: grade(evaluation, part, true), locked: locked)
                                    }
                                }.padding(.vertical, 3)
                            }
                        } header: {
                            VStack(alignment: .leading) {
                                Text(evaluation.name + " · " + evaluation.weight.formatted() + "%")
                                if evaluation.isGroup {
                                    let scores = Grades.scores(evaluation)
                                    Text("Se eliminan \(evaluation.dropLowestCount) · Promedio \(Grades.label(scores.map { Grades.truncate($0.reduce(0, +) / Decimal($0.count)) }))")
                                        .textCase(nil)
                                }
                            }
                        }
                    }
                }
                .navigationTitle(course.name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    if !locked {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button("Editar", systemImage: "pencil") { editing = true }
                        }
                    }
                }
                .sheet(isPresented: $editing) { CourseEditor(course: course, existing: true) }
            } else {
                ContentUnavailableView("Curso no disponible", systemImage: "book.closed")
            }
        }
    }

    private func grade(_ evaluation: Evaluation, _ part: Part, _ expected: Bool) -> Binding<Decimal?> {
        Binding {
            guard let stored = school.data.courses.first(where: { $0.id == courseID })?
                .evaluations.first(where: { $0.id == evaluation.id }) else { return nil }
            if stored.isGroup {
                guard let entry = stored.parts.first(where: { $0.id == part.id }) else { return nil }
                return expected ? entry.expectedGrade : entry.obtainedGrade
            }
            return expected ? stored.expectedGrade : stored.obtainedGrade
        } set: { value in
            guard var course = school.data.courses.first(where: { $0.id == courseID }),
                  let index = course.evaluations.firstIndex(where: { $0.id == evaluation.id }) else { return }
            if course.evaluations[index].isGroup {
                guard let partIndex = course.evaluations[index].parts.firstIndex(where: { $0.id == part.id }) else { return }
                if expected { course.evaluations[index].parts[partIndex].expectedGrade = value }
                else { course.evaluations[index].parts[partIndex].obtainedGrade = value }
            } else if expected { course.evaluations[index].expectedGrade = value }
            else { course.evaluations[index].obtainedGrade = value }
            school.put(course)
        }
    }
}

struct GradeField: View {
    let title: String
    @Binding var value: Decimal?
    var locked: Bool
    @State private var text = ""
    @FocusState private var focused: Bool

    init(_ title: String, value: Binding<Decimal?>, locked: Bool = false) {
        self.title = title
        self._value = value
        self.locked = locked
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            if locked { Text(Grades.label(value)).monospacedDigit() }
            else {
                TextField("—", text: $text)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(.roundedBorder)
                    .focused($focused)
                    .accessibilityLabel(title)
                    .onChange(of: text) { _, new in
                        if new.isEmpty { if value != nil { value = nil } }
                        else if let parsed = Grades.parse(new), value != parsed { value = parsed }
                    }
                    .onChange(of: value, initial: true) { _, new in
                        if !focused { text = new.map { NSDecimalNumber(decimal: $0).stringValue } ?? "" }
                    }
                    .onChange(of: focused) { _, active in
                        if !active { text = value.map { NSDecimalNumber(decimal: $0).stringValue } ?? "" }
                    }
            }
        }
    }
}

struct CourseEditor: View {
    @EnvironmentObject private var school: School
    @Environment(\.dismiss) private var dismiss
    @State var course: Course
    var existing = false
    @State private var confirmRetirement = false

    init(course: Course, existing: Bool = false) {
        self._course = State(initialValue: course)
        self.existing = existing
    }

    private var weight: Decimal { course.evaluations.reduce(0) { $0 + $1.weight } }
    private var canSave: Bool {
        !course.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && (
            course.evaluations.isEmpty || (weight == 100 && course.evaluations.allSatisfy {
                !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
                $0.weight > 0 && (!$0.isGroup || (!$0.parts.isEmpty && $0.parts.allSatisfy {
                    !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                }))
            }))
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Curso") {
                    TextField("Nombre", text: $course.name)
                    TextField("Código", text: $course.code)
                    TextField("Profesor", text: $course.teacherName)
                    TextField("¿Qué se necesita para aprobar?", text: $course.whatIsNeededToPass, axis: .vertical)
                    TextField("Observaciones", text: Binding(get: { course.notes ?? "" }, set: { course.notes = $0 }), axis: .vertical)
                }
                Section {
                    ForEach($course.evaluations) { $evaluation in
                        NavigationLink {
                            EvaluationEditor(evaluation: $evaluation)
                        } label: {
                            LabeledContent(evaluation.name.isEmpty ? "Evaluación sin nombre" : evaluation.name,
                                           value: evaluation.weight.formatted() + "%")
                        }
                    }.onDelete { course.evaluations.remove(atOffsets: $0) }
                    Button("Agregar evaluación", systemImage: "plus") { course.evaluations.append(Evaluation()) }
                } header: { Text("Evaluaciones") }
                  footer: { Text("Peso total: \(weight.formatted())%. Para calcular el promedio se requiere 100%.") }
                if existing {
                    Section {
                        Button("Me retiré del curso", role: .destructive) { confirmRetirement = true }
                    }
                }
            }
            .navigationTitle(existing ? "Editar curso" : "Nuevo curso")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") { school.put(course); dismiss() }.disabled(!canSave)
                }
            }
            .confirmationDialog("¿Retirarte del curso?", isPresented: $confirmRetirement, titleVisibility: .visible) {
                Button("Confirmar retiro", role: .destructive) {
                    if var recorded = school.data.courses.first(where: { $0.id == course.id }) {
                        recorded.isRetired = true
                        school.put(recorded)
                    }
                    dismiss()
                }
            }
        }
    }
}

struct EvaluationEditor: View {
    @Binding var evaluation: Evaluation
    var body: some View {
        Form {
            TextField("Nombre", text: $evaluation.name)
            TextField("Peso (%)", value: $evaluation.weight, format: .number).keyboardType(.decimalPad)
            Toggle("Grupo de evaluaciones", isOn: $evaluation.isGroup)
            if evaluation.isGroup {
                let maxDrops = max(0, evaluation.parts.count - 1)
                Stepper("Eliminar menores: \(evaluation.dropLowestCount)", value: $evaluation.dropLowestCount, in: 0...maxDrops)
                ForEach($evaluation.parts) { $part in
                    Section {
                        TextField("Nombre de la parte", text: $part.name)
                        OptionalDateField(date: $part.date)
                        GradeField("Obtenida", value: $part.obtainedGrade)
                        GradeField("Esperada", value: $part.expectedGrade)
                        Button("Eliminar parte", role: .destructive) {
                            let id = part.id
                            evaluation.parts.removeAll { $0.id == id }
                            evaluation.dropLowestCount = min(evaluation.dropLowestCount, max(0, evaluation.parts.count - 1))
                        }
                    }
                }
                Button("Agregar parte", systemImage: "plus") { evaluation.parts.append(Part()) }
            } else {
                OptionalDateField(date: $evaluation.date)
                GradeField("Obtenida", value: $evaluation.obtainedGrade)
                GradeField("Esperada", value: $evaluation.expectedGrade)
            }
        }.navigationTitle("Evaluación")
    }
}

struct OptionalDateField: View {
    @Binding var date: String?
    var body: some View {
        Toggle("Con fecha", isOn: Binding(get: { !(date ?? "").isEmpty },
                                         set: { date = $0 ? Dates.today : nil }))
        if let date, !date.isEmpty {
            DatePicker("Fecha", selection: Binding(get: { Dates.parse(date) ?? Date() },
                                                   set: { self.date = Dates.iso($0) }), displayedComponents: .date)
        }
    }
}
